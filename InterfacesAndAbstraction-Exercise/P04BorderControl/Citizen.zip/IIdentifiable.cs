﻿
namespace P04BorderControl
{
    public interface IIdentifiable
    {
        public string Id { get; set; }
    }
}
