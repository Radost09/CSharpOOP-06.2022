﻿namespace Operations
{
    public class MathOperations
    {
        public int Add(int numOne, int numTwo)
        {
            return numOne + numTwo;
        }
        public double Add(double numOne, double numTwo, double numThree)
        {
            return numOne + numTwo + numThree;
        }
        public decimal Add(decimal numOne, decimal numTwo, decimal numThree)
        {
            return numOne + numTwo + numThree;
        }
    }
}
