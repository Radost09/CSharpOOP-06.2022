﻿namespace P06FoodShortage
{
    public interface IIdentifiable
    {
        public string Id { get; set; }
    }
}
