﻿
namespace P05BirthdayCelebrations
{
    public interface IBirthable
    {
        string Birthdate { get; set; }
    }
}
