﻿namespace Raiding.Models.Interfaces
{
    public class IBaseHero
    {
        string Name { get; }
        int Power { get; }
    }
}
