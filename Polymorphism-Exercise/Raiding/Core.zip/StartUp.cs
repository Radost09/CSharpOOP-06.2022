﻿namespace Raiding
{
    using Raiding.Core;
    using System;
    public class StartUp
    {
        static void Main(string[] args)
        {
            try
            {
                Engine engine = new Engine();
                engine.Start();
            }
            catch (ArgumentException ae)
            {

                Console.WriteLine(ae.Message);
            }
              
         
        }
    }
}
