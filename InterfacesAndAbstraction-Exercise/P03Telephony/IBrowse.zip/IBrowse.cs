﻿
namespace P03Telephony
{
    public interface IBrowse
    {
        void Browse(string site)
        {

        }
    }
}
